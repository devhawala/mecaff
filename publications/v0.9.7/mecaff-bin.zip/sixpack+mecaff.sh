#
# This command file launches the VM/370 SixPack.
# Ensure that the Hercules executable (hercules) is in your path.
#

# check that java is on the PATH
#
java -version > /dev/null 2>&1
if [ $? -ne 0 ] ;
then
  echo "##"
  echo "## java not found to start MECAFF"
  echo "## ... ABORTING startup"
  echo "##"
  exit 1
fi

export configfile="sixpack+mecaff.conf"
export logfile="log.txt"

if [ -r ${logfile} ];
then
rm -rf ${logfile}
fi
if [ -r ${configfile} ];
then
export SLASH=/

# start the MECAFF process
#
java -cp . -jar mecaff.jar > mecaff.log &

# start some terminal emulators
#
(sleep 2 ; x3270 -title "VM/370 via MECAFF" -model 2 -oversize 87x34 127.0.0.1:3277) &

# start Hercules
#
hercules -f ${configfile} > ${logfile}

# stop all processes started above
#
ps -ef | grep 3270 | grep -v grep | awk '{system("kill -9 "$2" >/dev/null");}' > /dev/null 2> /dev/null
ps -ef | grep mecaff | grep java | grep -v grep | awk '{system("kill -9 "$2" >/dev/null");}' > /dev/null 2> /dev/null

fi

# eof
